from ztelemetrie.core import ZoranTelemetrie

zt = ZoranTelemetrie()
print(zt.enregistrer_signal("latence", 123))
print(zt.enregistrer_signal("énergie", 45))
print(zt.tableau_de_bord())
