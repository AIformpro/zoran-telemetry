class ZoranTelemetrie:
    def __init__(self):
        self.signaux = {}
    def enregistrer_signal(self, nom, valeur):
        self.signaux[nom] = valeur
        return f"Signal {nom} enregistré"
    def tableau_de_bord(self):
        return self.signaux
