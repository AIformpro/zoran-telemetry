from ztelemetrie.core import ZoranTelemetrie

def test_enregistrer_signal():
    zt = ZoranTelemetrie()
    res = zt.enregistrer_signal("latence", 123)
    assert "enregistré" in res and zt.signaux["latence"] == 123
